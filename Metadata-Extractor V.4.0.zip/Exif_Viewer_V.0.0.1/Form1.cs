﻿// --------------------------------------------
// Datei:			Metadata-Extractor
// Datum:			2021-02-15
// Ersteller:		Jan Stutz
// Version:		    3.0
// Änderungen:		-
// Beschreibung:
// Extrahiert Daten aus Bildern. Zusätzlich können noch Notizen getätigt werden.am Schluss kann man die Notizen und Metadaten exportieren.
// --------------------------------------------


// PROGRAMM MUSS ALS ADMINISTRATOR GESTARTET WERDEN, WEGEN DEM C:\\ PFAD!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Web;
using System.IO;
using ExifLib;
using System.Windows.Forms;

// Für dieses Projekt wird die Exiflib benötigt.  

namespace Exif_Viewer_V._0._0._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            metadata_textbox.Multiline = true;
            metadata_textbox.ScrollBars = ScrollBars.Both;
            metadata_textbox.ReadOnly = true;
            ja.Checked = false;
            nein.Checked = true;
            notes.ScrollBars = ScrollBars.Both;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Bilddateien |*.jpg";
            openFileDialog1.ShowDialog();
            pictureBox1.ImageLocation = openFileDialog1.FileName;
            path.Text = openFileDialog1.FileName;
            datenaktualisieren_button.PerformClick();
        }



        private void datenaktualisieren_button_Click(object sender, EventArgs e)
        {
            //Wenn ein Bild hochgeladen wird, dann wird automatisch der Button betätigt.
            // Um dem Benutzer zu trollen habe ich den Button, für den Benutzer sichtbar gemacht und damit sich der Benutzer wichtig fühlen kann.
            // Hier werden die Metadaten extrahiert. Mit dem ersten try-catch Block werden versucht, alle Metadaten herauszufiltern. Falls keine Daten vorhanden sind,
            // wird das Programm mit einer Fehlermeldung abgebrochen. 

            string Bildpfad = path.Text;
            metadata_textbox.Clear();
            try
            {
                ExifReader tstview = new ExifReader(Bildpfad);
            }
            catch (SystemException ex)
            {
                MessageBox.Show("Es wurden keine Metadaten gefunden.\nBitte laden sie ein gültiges Bild hoch.\nProgramm wird abgebrochen.\n\n ---------FEHLERMELDUNG:---------\n\n" + ex);
                Application.Exit();
                this.Close();
            }
            ExifReader exifview = new ExifReader(Bildpfad);
            const int arraygrösse = 13;

            // Zuerst werden hier unten die Tags definiert, die aus dem Bild herausgefiltert werden sollte. Oben habe ich einen String, der das ganze für den Benutzer erkennbar macht, werlcher Tag 
            // welchen Zweck erfüllt. Wenn zu einem Tag keine Daten gefunden werden, dann soll eine Fehlermeldung erscheinen. 
            // Wären die Tags nicht, wäre der Code viel länger. Im unteren Try- Catch Teil wird versucht, Daten aus einem Bild zu lesen. Werden keine Daten zu diesem Tag gefunden,
            // Erscheint Eine Meldung, die den Benutzer darauf aufmerksam macht.

                string[] Eigenschaft = new string[arraygrösse] { "Marke:\t", "Modell:\t","Kamera S/No:","Linsenmodell:", "Linsen S/No:", "Künstler:\t", "Zeitpunkt:", "Schärfe:\t",                                                                   "Software:\t", "Kontrast:\t","Blitz:\t", "Blitzlicht:\t", "ISO Geschw.:" };              
                Object[] Objekte = new object[arraygrösse] { ExifTags.Make, ExifTags.Model,ExifTags.BodySerialNumber, ExifTags.LensModel, ExifTags.LensSerialNumber,  ExifTags.Artist, ExifTags.DateTimeOriginal, ExifTags.Sharpness, ExifTags.Software, ExifTags.Contrast, ExifTags.Flash, ExifTags.FlashEnergy, ExifTags.ISOSpeed };
                int i = 0;

                foreach (object item in Objekte)
                {
                    string text = Eigenschaft[i];
                    string text2 = Eigenschaft[i];
                try
                {
                    if (exifview.GetTagValue<string>((ushort)item, out text))
                        metadata_textbox.Text += ($"{text2}\t" + text.ToString() + "\r\n");

                    else
                    {
                        metadata_textbox.Text += ($"{text2}\t" + "N/V.\r\n");
                    }
                
                }
                catch (SystemException ex)
                {
                    MessageBox.Show("Ein Tag konnte leider nicht gelesen werden.");
                }
                    i++;
                }
                }

        // Wenn dieser Button gedrückt wird, dann werden die Notizen gelöscht.
        private void button2_Click(object sender, EventArgs e)
        {
            notes.Text = "";
        }


        // Der untenstehende Block ist für das exportieren der Notizen/ Metadaten zuständig. Der obere Block exportiert ein Textdokument mit Notizen und den Metadaten.
        // Der untenstehende Block exportiert nur die Metadaten. Wennn das speichern nicht klappte (da der Benutzer evtl. zu wenige Rechte hatte), wird das Programm mit
        // der entsprechenden Fehlermeldung beendet
        // Die Zahl, die vor ".txt" steht, ist das aktuelle Datum und die Zeit.
        private void export_apply_Click(object sender, EventArgs e)
        {
            if (ja.Checked)
            {
                var datum = DateTime.Now.ToString("dMyyyyHHmmss");
                var datumtext = DateTime.Now.ToString();
                //var datum = DateTime.Now.ToString("MdyyyyHHmmss");
                var speicherpfad = $@"C:\Exif_Export_mit Notizen{datum}.txt";
                var text = $"{metadata_textbox.Text}\n\n----------Notizen----------\n\n{notes.Text}"+$"\n\n\n\nExportiert am: {datumtext} von Metadata- Extractor";


                try
                {
                    using (var schreiber = new StreamWriter(speicherpfad))
                    {
                        schreiber.Write(text);
                        MessageBox.Show("Der Export der Metadaten und Notizen wurde erfolgreich durchgeführt.", "Exportvorgang erfolgreich.", MessageBoxButtons.OK, MessageBoxIcon.Information, 0);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Leider ist etwas beim Speichervorgang schiefgelaufen. Bitte führen sie das Programm nochmals als Admin aus.\n" + ex+"\n\nProgramm wird beendet.");
                    this.Close();
                }
            }

            else
            {
                var datum = DateTime.Now.ToString("dMyyyyHHmmss");
                var datumtext = DateTime.Now.ToString();
                //var datum = DateTime.Now.ToString("MdyyyyHHmmss");
                var speicherpfad = $@"C:\Exif_Export_ohne Notizen{datum}.txt";
                var text = $"{metadata_textbox.Text}\n\n\n\nExportiert am: {datumtext} von Metadata-Extractor";

                try
                {
                    using (var schreiber = new StreamWriter(speicherpfad))
                    {
                        schreiber.Write(text);
                        MessageBox.Show("Der Export der Metadaten wurde erfolgreich durchgeführt.", "Exportvorgang erfolgreich.", MessageBoxButtons.OK, MessageBoxIcon.Information,0);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Leider ist etwas beim Speichervorgang schiefgelaufen. Das Programm wird beendet. Bitte führen sie das Programm nochmals als Admin aus.\n" + ex);
                    this.Close();
                }
            }
        }
    }
}
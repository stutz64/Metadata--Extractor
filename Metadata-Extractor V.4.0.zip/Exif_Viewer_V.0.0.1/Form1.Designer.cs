﻿
namespace Exif_Viewer_V._0._0._1
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.path = new System.Windows.Forms.Label();
            this.metadata_textbox = new System.Windows.Forms.TextBox();
            this.notizen = new System.Windows.Forms.Label();
            this.notes = new System.Windows.Forms.TextBox();
            this.datenaktualisieren_button = new System.Windows.Forms.Button();
            this.export_apply = new System.Windows.Forms.Button();
            this.nein = new System.Windows.Forms.RadioButton();
            this.ja = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Export = new System.Windows.Forms.SaveFileDialog();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(485, 425);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(520, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Bildpfad: ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(660, 7);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Browse";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(520, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Metadaten:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(520, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Pfad ";
            // 
            // path
            // 
            this.path.AutoSize = true;
            this.path.Location = new System.Drawing.Point(657, 57);
            this.path.Name = "path";
            this.path.Size = new System.Drawing.Size(28, 13);
            this.path.TabIndex = 5;
            this.path.Text = "-------";
            // 
            // metadata_textbox
            // 
            this.metadata_textbox.Cursor = System.Windows.Forms.Cursors.No;
            this.metadata_textbox.Location = new System.Drawing.Point(523, 124);
            this.metadata_textbox.Multiline = true;
            this.metadata_textbox.Name = "metadata_textbox";
            this.metadata_textbox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.metadata_textbox.Size = new System.Drawing.Size(282, 218);
            this.metadata_textbox.TabIndex = 7;
            // 
            // notizen
            // 
            this.notizen.AutoSize = true;
            this.notizen.Location = new System.Drawing.Point(875, 108);
            this.notizen.Name = "notizen";
            this.notizen.Size = new System.Drawing.Size(43, 13);
            this.notizen.TabIndex = 9;
            this.notizen.Text = "Notizen";
            // 
            // notes
            // 
            this.notes.Location = new System.Drawing.Point(878, 124);
            this.notes.Multiline = true;
            this.notes.Name = "notes";
            this.notes.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.notes.Size = new System.Drawing.Size(282, 218);
            this.notes.TabIndex = 10;
            // 
            // datenaktualisieren_button
            // 
            this.datenaktualisieren_button.Location = new System.Drawing.Point(523, 349);
            this.datenaktualisieren_button.Name = "datenaktualisieren_button";
            this.datenaktualisieren_button.Size = new System.Drawing.Size(235, 23);
            this.datenaktualisieren_button.TabIndex = 11;
            this.datenaktualisieren_button.Text = "Daten aktualisieren";
            this.datenaktualisieren_button.UseVisualStyleBackColor = true;
            this.datenaktualisieren_button.Click += new System.EventHandler(this.datenaktualisieren_button_Click);
            // 
            // export_apply
            // 
            this.export_apply.Location = new System.Drawing.Point(931, 404);
            this.export_apply.Name = "export_apply";
            this.export_apply.Size = new System.Drawing.Size(229, 27);
            this.export_apply.TabIndex = 15;
            this.export_apply.Text = "Export";
            this.export_apply.UseVisualStyleBackColor = true;
            this.export_apply.Click += new System.EventHandler(this.export_apply_Click);
            // 
            // nein
            // 
            this.nein.AutoSize = true;
            this.nein.Location = new System.Drawing.Point(878, 421);
            this.nein.Name = "nein";
            this.nein.Size = new System.Drawing.Size(47, 17);
            this.nein.TabIndex = 14;
            this.nein.TabStop = true;
            this.nein.Text = "Nein";
            this.nein.UseVisualStyleBackColor = true;
            // 
            // ja
            // 
            this.ja.AutoSize = true;
            this.ja.Location = new System.Drawing.Point(878, 398);
            this.ja.Name = "ja";
            this.ja.Size = new System.Drawing.Size(36, 17);
            this.ja.TabIndex = 13;
            this.ja.TabStop = true;
            this.ja.Text = "Ja";
            this.ja.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(520, 411);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(193, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Möchten sie Ihre Notizen mitspeichern?";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Exif_Viewer_V._0._0._1.Properties.Resources.camera_png;
            this.pictureBox2.Location = new System.Drawing.Point(749, 7);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(56, 37);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(878, 349);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(282, 23);
            this.button2.TabIndex = 17;
            this.button2.Text = "Notizen löschen";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1207, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.export_apply);
            this.Controls.Add(this.nein);
            this.Controls.Add(this.ja);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.datenaktualisieren_button);
            this.Controls.Add(this.notes);
            this.Controls.Add(this.notizen);
            this.Controls.Add(this.metadata_textbox);
            this.Controls.Add(this.path);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Metadata-Viewer";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label path;
        private System.Windows.Forms.TextBox metadata_textbox;
        private System.Windows.Forms.Label notizen;
        private System.Windows.Forms.TextBox notes;
        private System.Windows.Forms.Button datenaktualisieren_button;
        private System.Windows.Forms.Button export_apply;
        private System.Windows.Forms.RadioButton nein;
        private System.Windows.Forms.RadioButton ja;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.SaveFileDialog Export;
        private System.Windows.Forms.Button button2;
    }
}

